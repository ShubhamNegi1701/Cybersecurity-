library(depmixS4)
library(ggplot2)
library(dplyr)
library(chron)
library(lubridate)
library(EnvStats)
library(modeest)
library(hydroTSM)

#to prodice results again
set.seed(1)

#Read TRAIN data into dataframe
dataSet1 <- read.table("TrainData.txt", header = TRUE, sep = ",", dec = ".")

dataSet1 <- na.omit(dataSet1)


#Set Date structure using POSIXlt
dataSet1$Date <- as.POSIXct(dataSet1$Date, format = "%d/%m/%Y")

#Create new column that displays weekday (0:6 where 0 == Sunday)
dataSet1$Day <- as.POSIXlt(dataSet1$Date)$wday



#Trimming excess data from 2006 and 2009 to have a more usable dataset
modified_DS <- dataSet1[format(dataSet1$Date,'%Y') != "2006" & format(dataSet1$Date,'%Y') != "2009", ]


for(i in 1:ncol(modified_DS)) {
  modified_DS[is.na(modified_DS[,i]), i] <- mean(modified_DS[,i], na.rm = TRUE)
}

#loading weekday data into ds_wDay1
ds_wDay1 <- modified_DS[which(weekdays(as.POSIXlt(modified_DS$Date)) %in% c('Monday','Tuesday','Wednesday','Thursday','Friday' )),]

#loading weekend data into ds_wDay2
ds_wEnd1 <- modified_DS[which(weekdays(as.POSIXlt(modified_DS$Date)) %in% c('Saturday','Sunday' )),]

#loading time window into ds_wDay_D1
ds_wDay_D1 <- ds_wDay1[(times(ds_wDay1$Time, format = "h:m:s") > times("08:00:00", format = "h:m:s")) == TRUE,]
ds_wDay_D1 <- ds_wDay_D1[(times(ds_wDay_D1$Time, format = "h:m:s") < times("12:00:00", format = "h:m:s")) == TRUE,]

#loading time window into ds_wEnd_D1
ds_wEnd_D1 <- ds_wEnd1[(times(ds_wEnd1$Time, format = "h:m:s") > times("08:00:00", format = "h:m:s")) == TRUE,]
ds_wEnd_D1 <- ds_wEnd_D1[(times(ds_wEnd_D1$Time, format = "h:m:s") < times("12:00:00", format = "h:m:s")) == TRUE,]



ds_Monday <-ds_wDay_D1[which(weekdays(as.POSIXlt(ds_wDay_D1$Date)) %in% c('Monday')),]
ds_Tuesday <-ds_wDay_D1[which(weekdays(as.POSIXlt(ds_wDay_D1$Date)) %in% c('Tuesday')),]


ds_Saturday <-ds_wEnd_D1[which(weekdays(as.POSIXlt(ds_wEnd_D1$Date)) %in% c('Saturday')),]
#Set Date & Time structure of ds_Monday dataframe using POSIXct so it can be plotted using ggplot
ds_Monday$Date <- as.POSIXct(ds_Monday$Date, format = "%d/%m/%Y") 
ds_Tuesday$Date <- as.POSIXct(ds_Tuesday$Date, format = "%d/%m/%Y") 

ds_Saturday$Date <- as.POSIXct(ds_Saturday$Date, format = "%d/%m/%Y")


#Plot the Global_active_power of the 24 hour window Mondays for the whole year
ggplot(ds_Monday, aes(x = Date, y = Global_active_power, na.rm = TRUE))+geom_point()+geom_smooth()
#Plot the Global_active_power of the 24 hour window Mondays for the whole year
ggplot(ds_Tuesday, aes(x = Date, y = Global_active_power, na.rm = TRUE))+geom_point()+geom_smooth()
#Plot the Global_active_power of the 24 hour window Tuesday for the whole year
ggplot(ds_Saturday, aes(x = Date, y = Global_active_power, na.rm = TRUE))+geom_point()+geom_smooth()

#Corelation matrix
corelMat = cor(modified_DS[sapply(modified_DS, function(x)is.numeric(x))],use ="complete.obs", method = "pearson")

#for(i in 1:ncol(modified_DS)) {
#  modified_DS[is.na(modified_DS[,i]), i] <- mean(modified_DS[,i], na.rm = TRUE)
#}
