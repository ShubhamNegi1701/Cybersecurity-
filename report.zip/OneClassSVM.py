#!/usr/bin/env python
# coding: utf-8

# In[2]:


import os
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from sklearn import svm
import sklearn
from sklearn import linear_model, preprocessing
import numpy as np
import pandas as pd
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')
from collections import Counter
import warnings
warnings.filterwarnings("ignore")
import time

import numpy as np
import matplotlib
import matplotlib.pyplot as plt

from sklearn import svm
from sklearn.datasets import make_moons, make_blobs
from sklearn.covariance import EllipticEnvelope
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor


# In[17]:


df = pd.read_csv("C:\\Users\\User\\Documents\\CMPT318\\TrainData.txt")
df2 = pd.read_csv("C:\\Users\\User\\Documents\\CMPT318\\test3.txt")


# In[4]:


df


# In[18]:


df2


# In[19]:


df3 = pd.concat([df, df2])


# In[20]:


df3


# In[21]:


df3["weekday"] = pd.to_datetime(df3.Date).dt.dayofweek #creating a column for weekdays


# In[22]:


df_mondays1 = df3.loc[df3["weekday"] ==0] #creating a dataframe that contains only mondays


# In[23]:


#Trying to select a time window between 8 am to 12 pm
df_mondays1[['h','m','s']] = df_mondays1['Time'].astype(str).str.split(':', expand=True).astype(int)


# In[24]:


dfM1 =df_mondays1[df_mondays1['h'].between(8, 12, inclusive=True)]


# In[25]:


dfM1


# In[26]:


#selecting variables of interest
dfM1 = dfM1[['Date', 'Time', 'Global_active_power', 'h', 'm', 's']]


# In[27]:


dfM1['Global_active_power'].describe()
#one anomoly is the maximum global active power of 7.64


# In[28]:


dfM.plot(x='Date', y='Global_active_power', figsize=(12,6))
plt.xlabel('Date time')
plt.ylabel('Global Active Power (in kilowats)')


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[5]:


df.index


# In[6]:


df["weekday"] = pd.to_datetime(df.Date).dt.dayofweek #creating a column for weekdays


# In[7]:


df_mondays = df.loc[df["weekday"] ==0] #creating a dataframe that contains only mondays


# In[8]:


#Trying to select a time window between 8 am to 12 pm
df_mondays[['h','m','s']] = df_mondays['Time'].astype(str).str.split(':', expand=True).astype(int)


# In[9]:


dfM =df_mondays[df_mondays['h'].between(8, 12, inclusive=True)]


# In[10]:


dfM.info()


# In[11]:


#selecting variables of interest
dfM = dfM[['Date', 'Time', 'Global_active_power', 'h', 'm', 's']]


# In[12]:


dfM['Global_active_power'].describe()
#one anomoly is the maximum global active power of 7.64


# In[29]:


dfM1.plot(x='Date', y='Global_active_power', figsize=(12,6))
plt.xlabel('Date time')
plt.ylabel('Global Active Power (in kilowats)')


# In[31]:


dfM1['Global_active_power'].describe()


# In[30]:


dfM1 = dfM1.sort_values('Date')

data = dfM1[['Global_active_power']]
scaler = StandardScaler()
np_scaled = scaler.fit_transform(data)
data = pd.DataFrame(np_scaled)
# train oneclassSVM 
model = svm.OneClassSVM(nu=0.5, kernel="rbf", gamma=0.04)
model.fit(data)
dfM1['anomaly3'] = pd.Series(model.predict(data))

fig, ax = plt.subplots(figsize=(12,6))
a = dfM1.loc[dfM1['anomaly3'] == -1, ['Date', 'Global_active_power']] #anomaly

ax.plot(dfM1['Date'], dfM1['Global_active_power'], color='blue', label='Normal')
ax.scatter(a['Date'],a['Global_active_power'], color='red', label='Anomaly')
plt.xlabel('Date time')
plt.ylabel('Global Active Power in kilowats')
plt.legend()
plt.show();


# In[ ]:





# In[ ]:





# In[ ]:





# In[16]:


dfM = dfM.sort_values('Date')

data = dfM[['Global_active_power']]
scaler = StandardScaler()
np_scaled = scaler.fit_transform(data)
data = pd.DataFrame(np_scaled)
# train oneclassSVM 
model = svm.OneClassSVM(nu=0.5, kernel="rbf", gamma=0.04)
model.fit(data)
dfM['anomaly3'] = pd.Series(model.predict(data))

fig, ax = plt.subplots(figsize=(12,6))
a = dfM.loc[dfM['anomaly3'] == -1, ['Date', 'Global_active_power']] #anomaly

ax.plot(dfM['Date'], dfM['Global_active_power'], color='blue', label='Normal')
ax.scatter(a['Date'],a['Global_active_power'], color='red', label='Anomaly')
plt.xlabel('Date time')
plt.ylabel('Global Active Power in kilowats')
plt.legend()
plt.show();


# In[ ]:





# In[ ]:




